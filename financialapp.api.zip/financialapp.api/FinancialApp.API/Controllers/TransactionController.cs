﻿namespace FinancialApp.API.Controllers
{
    public class TransactionController
    {
    }
}
